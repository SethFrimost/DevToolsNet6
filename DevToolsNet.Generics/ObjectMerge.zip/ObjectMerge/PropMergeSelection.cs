﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DevToolsNet.Generics.ObjectMerge
{
    public enum PropMergeSelection
    {
        None, X, Y
    }
}
